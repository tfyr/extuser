from django.apps import AppConfig


class ExtuserConfig(AppConfig):
    name = 'extuser'
